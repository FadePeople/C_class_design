/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../check/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[25];
    char stringdata0[416];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 16), // "on_num_0_clicked"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 16), // "on_num_1_clicked"
QT_MOC_LITERAL(4, 46, 16), // "on_num_2_clicked"
QT_MOC_LITERAL(5, 63, 16), // "on_num_3_clicked"
QT_MOC_LITERAL(6, 80, 16), // "on_num_4_clicked"
QT_MOC_LITERAL(7, 97, 16), // "on_num_5_clicked"
QT_MOC_LITERAL(8, 114, 16), // "on_num_6_clicked"
QT_MOC_LITERAL(9, 131, 16), // "on_num_7_clicked"
QT_MOC_LITERAL(10, 148, 16), // "on_num_8_clicked"
QT_MOC_LITERAL(11, 165, 16), // "on_num_9_clicked"
QT_MOC_LITERAL(12, 182, 18), // "on_bu_dian_clicked"
QT_MOC_LITERAL(13, 201, 19), // "on_bu_cheng_clicked"
QT_MOC_LITERAL(14, 221, 18), // "on_bu_jian_clicked"
QT_MOC_LITERAL(15, 240, 17), // "on_bu_jia_clicked"
QT_MOC_LITERAL(16, 258, 17), // "on_bu_chu_clicked"
QT_MOC_LITERAL(17, 276, 15), // "on_bu_C_clicked"
QT_MOC_LITERAL(18, 292, 16), // "on_bu_De_clicked"
QT_MOC_LITERAL(19, 309, 16), // "on_bu_g2_clicked"
QT_MOC_LITERAL(20, 326, 16), // "on_bu_g3_clicked"
QT_MOC_LITERAL(21, 343, 17), // "on_bu_sin_clicked"
QT_MOC_LITERAL(22, 361, 17), // "on_bu_cos_clicked"
QT_MOC_LITERAL(23, 379, 17), // "on_bu_tan_clicked"
QT_MOC_LITERAL(24, 397, 18) // "on_bu_deng_clicked"

    },
    "MainWindow\0on_num_0_clicked\0\0"
    "on_num_1_clicked\0on_num_2_clicked\0"
    "on_num_3_clicked\0on_num_4_clicked\0"
    "on_num_5_clicked\0on_num_6_clicked\0"
    "on_num_7_clicked\0on_num_8_clicked\0"
    "on_num_9_clicked\0on_bu_dian_clicked\0"
    "on_bu_cheng_clicked\0on_bu_jian_clicked\0"
    "on_bu_jia_clicked\0on_bu_chu_clicked\0"
    "on_bu_C_clicked\0on_bu_De_clicked\0"
    "on_bu_g2_clicked\0on_bu_g3_clicked\0"
    "on_bu_sin_clicked\0on_bu_cos_clicked\0"
    "on_bu_tan_clicked\0on_bu_deng_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  129,    2, 0x08 /* Private */,
       3,    0,  130,    2, 0x08 /* Private */,
       4,    0,  131,    2, 0x08 /* Private */,
       5,    0,  132,    2, 0x08 /* Private */,
       6,    0,  133,    2, 0x08 /* Private */,
       7,    0,  134,    2, 0x08 /* Private */,
       8,    0,  135,    2, 0x08 /* Private */,
       9,    0,  136,    2, 0x08 /* Private */,
      10,    0,  137,    2, 0x08 /* Private */,
      11,    0,  138,    2, 0x08 /* Private */,
      12,    0,  139,    2, 0x08 /* Private */,
      13,    0,  140,    2, 0x08 /* Private */,
      14,    0,  141,    2, 0x08 /* Private */,
      15,    0,  142,    2, 0x08 /* Private */,
      16,    0,  143,    2, 0x08 /* Private */,
      17,    0,  144,    2, 0x08 /* Private */,
      18,    0,  145,    2, 0x08 /* Private */,
      19,    0,  146,    2, 0x08 /* Private */,
      20,    0,  147,    2, 0x08 /* Private */,
      21,    0,  148,    2, 0x08 /* Private */,
      22,    0,  149,    2, 0x08 /* Private */,
      23,    0,  150,    2, 0x08 /* Private */,
      24,    0,  151,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_num_0_clicked(); break;
        case 1: _t->on_num_1_clicked(); break;
        case 2: _t->on_num_2_clicked(); break;
        case 3: _t->on_num_3_clicked(); break;
        case 4: _t->on_num_4_clicked(); break;
        case 5: _t->on_num_5_clicked(); break;
        case 6: _t->on_num_6_clicked(); break;
        case 7: _t->on_num_7_clicked(); break;
        case 8: _t->on_num_8_clicked(); break;
        case 9: _t->on_num_9_clicked(); break;
        case 10: _t->on_bu_dian_clicked(); break;
        case 11: _t->on_bu_cheng_clicked(); break;
        case 12: _t->on_bu_jian_clicked(); break;
        case 13: _t->on_bu_jia_clicked(); break;
        case 14: _t->on_bu_chu_clicked(); break;
        case 15: _t->on_bu_C_clicked(); break;
        case 16: _t->on_bu_De_clicked(); break;
        case 17: _t->on_bu_g2_clicked(); break;
        case 18: _t->on_bu_g3_clicked(); break;
        case 19: _t->on_bu_sin_clicked(); break;
        case 20: _t->on_bu_cos_clicked(); break;
        case 21: _t->on_bu_tan_clicked(); break;
        case 22: _t->on_bu_deng_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 23;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
